import React, { useEffect, useState } from 'react';

const API = process.env.REACT_APP_API_URL || 'http://localhost:8000';

function App() {
  const [status, setStatus] = useState(null);
  const [stats, setStats] = useState(null);
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Vérifier la santé de l'API
    fetch(`${API}/health`)
      .then(r => r.json())
      .then(d => setStatus(d.status))
      .catch(() => setStatus('unreachable'));

    // Récupérer les stats du dashboard
    fetch(`${API}/api/v1/dashboard/stats`)
      .then(r => r.json())
      .then(d => setStats(d))
      .catch(() => {});

    // Récupérer les équipements
    fetch(`${API}/api/v1/devices/`)
      .then(r => r.json())
      .then(d => setDevices(d))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const styles = {
    app: { fontFamily: 'system-ui, sans-serif', background: '#0f172a', minHeight: '100vh', color: '#e2e8f0', padding: '0' },
    header: { background: '#1e293b', borderBottom: '1px solid #334155', padding: '16px 32px', display: 'flex', alignItems: 'center', gap: '12px' },
    logo: { fontSize: '22px', fontWeight: '700', color: '#38bdf8', letterSpacing: '-0.5px' },
    badge: { fontSize: '11px', padding: '2px 8px', borderRadius: '20px', background: status === 'ok' ? '#064e3b' : '#450a0a', color: status === 'ok' ? '#34d399' : '#f87171' },
    main: { padding: '32px' },
    grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '16px', marginBottom: '32px' },
    card: { background: '#1e293b', border: '1px solid #334155', borderRadius: '12px', padding: '20px' },
    cardLabel: { fontSize: '12px', color: '#94a3b8', marginBottom: '6px' },
    cardValue: { fontSize: '28px', fontWeight: '700', color: '#f1f5f9' },
    cardSub: { fontSize: '12px', color: '#64748b', marginTop: '4px' },
    section: { marginBottom: '32px' },
    sectionTitle: { fontSize: '16px', fontWeight: '600', color: '#94a3b8', marginBottom: '16px', textTransform: 'uppercase', letterSpacing: '0.05em' },
    table: { width: '100%', borderCollapse: 'collapse' },
    th: { textAlign: 'left', padding: '10px 16px', fontSize: '12px', color: '#64748b', borderBottom: '1px solid #334155' },
    td: { padding: '12px 16px', fontSize: '13px', borderBottom: '1px solid #1e293b' },
    dot: (up) => ({ display: 'inline-block', width: '8px', height: '8px', borderRadius: '50%', background: up ? '#34d399' : '#f87171', marginRight: '8px' }),
    typeBadge: { fontSize: '11px', padding: '2px 8px', borderRadius: '6px', background: '#1e3a5f', color: '#7dd3fc' },
    empty: { textAlign: 'center', padding: '60px 20px', color: '#475569' },
    scanBtn: { background: '#0ea5e9', color: '#fff', border: 'none', borderRadius: '8px', padding: '10px 20px', fontSize: '14px', cursor: 'pointer', marginBottom: '24px' },
    link: { color: '#38bdf8', fontSize: '13px' },
    apiBox: { background: '#1e293b', border: '1px solid #334155', borderRadius: '12px', padding: '20px', marginBottom: '24px' },
  };

  return (
    <div style={styles.app}>
      {/* Header */}
      <div style={styles.header}>
        <span style={styles.logo}>⬡ ULRICH</span>
        <span style={{ color: '#475569', fontSize: '13px' }}>Network Supervision</span>
        <span style={{ flex: 1 }} />
        <span style={styles.badge}>
          {status === 'ok' ? '● API connectée' : status === null ? '○ Connexion...' : '● API hors ligne'}
        </span>
      </div>

      <div style={styles.main}>

        {/* Lien API Docs */}
        <div style={styles.apiBox}>
          <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '6px' }}>Phase 1 opérationnelle ✅</div>
          <div style={{ fontSize: '13px', color: '#94a3b8' }}>
            Interface API complète disponible sur{' '}
            <a href="http://localhost:8000/docs" target="_blank" rel="noreferrer" style={styles.link}>
              http://localhost:8000/docs ↗
            </a>
            {' '}— Lance un scan depuis l'API pour découvrir tes équipements.
          </div>
        </div>

        {/* Stats */}
        {stats && (
          <div style={styles.grid}>
            <div style={styles.card}>
              <div style={styles.cardLabel}>Équipements total</div>
              <div style={styles.cardValue}>{stats.total_devices}</div>
            </div>
            <div style={styles.card}>
              <div style={styles.cardLabel}>En ligne</div>
              <div style={{ ...styles.cardValue, color: '#34d399' }}>{stats.devices_up}</div>
            </div>
            <div style={styles.card}>
              <div style={styles.cardLabel}>Hors ligne</div>
              <div style={{ ...styles.cardValue, color: stats.devices_down > 0 ? '#f87171' : '#34d399' }}>{stats.devices_down}</div>
            </div>
            <div style={styles.card}>
              <div style={styles.cardLabel}>Disponibilité</div>
              <div style={{ ...styles.cardValue, color: '#38bdf8' }}>{stats.uptime_percent}%</div>
            </div>
            <div style={styles.card}>
              <div style={styles.cardLabel}>Incidents ouverts</div>
              <div style={{ ...styles.cardValue, color: stats.open_incidents > 0 ? '#fb923c' : '#34d399' }}>{stats.open_incidents}</div>
            </div>
          </div>
        )}

        {/* Liste équipements */}
        <div style={styles.section}>
          <div style={styles.sectionTitle}>Équipements découverts</div>

          {loading ? (
            <div style={styles.empty}>Chargement...</div>
          ) : devices.length === 0 ? (
            <div style={styles.empty}>
              <div style={{ fontSize: '40px', marginBottom: '12px' }}>🔍</div>
              <div style={{ fontSize: '15px', marginBottom: '8px' }}>Aucun équipement détecté</div>
              <div style={{ fontSize: '13px' }}>
                Lance un scan depuis{' '}
                <a href="http://localhost:8000/docs#/Scanner%20réseau/launch_scan_api_v1_scan__post" target="_blank" rel="noreferrer" style={styles.link}>
                  l'API Swagger ↗
                </a>
              </div>
            </div>
          ) : (
            <div style={{ background: '#1e293b', border: '1px solid #334155', borderRadius: '12px', overflow: 'hidden' }}>
              <table style={styles.table}>
                <thead>
                  <tr>
                    <th style={styles.th}>Statut</th>
                    <th style={styles.th}>IP</th>
                    <th style={styles.th}>Hostname</th>
                    <th style={styles.th}>Type</th>
                    <th style={styles.th}>Latence</th>
                    <th style={styles.th}>Uptime 24h</th>
                    <th style={styles.th}>Dernière vue</th>
                  </tr>
                </thead>
                <tbody>
                  {devices.map(d => (
                    <tr key={d.id} style={{ background: d.is_up === false ? '#1a0a0a' : 'transparent' }}>
                      <td style={styles.td}>
                        <span style={styles.dot(d.is_up !== false)} />
                        {d.is_up === false ? 'Hors ligne' : 'En ligne'}
                      </td>
                      <td style={{ ...styles.td, fontFamily: 'monospace', color: '#7dd3fc' }}>{d.ip_address}</td>
                      <td style={{ ...styles.td, color: '#94a3b8' }}>{d.hostname || '—'}</td>
                      <td style={styles.td}><span style={styles.typeBadge}>{d.device_type}</span></td>
                      <td style={styles.td}>{d.latency_ms ? `${d.latency_ms} ms` : '—'}</td>
                      <td style={styles.td}>{d.uptime_percent != null ? `${d.uptime_percent}%` : '—'}</td>
                      <td style={{ ...styles.td, color: '#64748b', fontSize: '12px' }}>
                        {d.last_seen ? new Date(d.last_seen).toLocaleString('fr-FR') : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

export default App;
